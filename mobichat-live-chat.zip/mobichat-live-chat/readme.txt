===MobiChat Live Chat ===
Contributors: (mobichat)
Tags: chat, chat online, contact plugin, contact us, customer support, free chat, chat software, IM chat, live chat, live chat inc, live chat services, live chat software, live chatting, live help, live support, live web chat, livechat, live help, live support, olark, online chat, online support, php live chat, snapengage, support software, website chat, wordpress chat, wordpress live chat, wordpress live chat plugin, Zopim, mobile live chat, mobile lead generation, lead generation, mobichat, zendesk, Zopim live chat, banckle, clickdesk, click desk
Requires at least: 3.1
Tested up to: 4.1.1
Stable tag: 1.0
MobiChat is the only live chat built for mobile first. Get more Customers! 

License: GPLv2 or later.

== Description ==

**The Facts About MobiChat and Your Customers**


It�s a fact that your customers need guidance when making a buying decision. MobiChat helps you give that guidance with a superior 1 on 1 chat experience. The MobiChat live chat experience helps you build connections with your potential and existing customers.

Chat with one or many customers at the same time.

Responsive Design � Whether your customer is on a mobile device or desktop PC, our chat adjusts to provide them the best user experience

Customized Branding - Use your company logo and agent headshots to give a true branded 1 on 1 experience

Capture Leads Right in the Chat � With RealCapture you setup custom questions and customers answer them right in the chat. Perfect for mobile lead generation



**Why Use MobiChat over the other chat companies?**


MobiChat is live chat built to help your business succeed. We give you the features of the big chat providers with the prices of the small ones. Look at some of the options that make MobiChat better than everyone else.

Better Unavailable Options � Face it you cannot be in front your PC to answer chats all the time. We provide three proven options to make sure you do not lose customers when you are not there. Our SMS Chat Invite, Unavailable Lead Capture, and Mobile Apps cannot be beat

Built for Mobile First � No live chat provides a better experience.

24/7 365 Support from our trained experts who will help with all and everything you need.

Very Customizable � You can modify the customer experience to your exact needs



**More Features**

Run Multiple Campaigns at Once � Support and Sales can have their own lead captures and campaign to provide the best possible experience.

Assign agents to Multiple Campaigns � Agents can serve different departments

Click to Call � 1 Click for any mobile phone

Android and Iphone IOS Agent apps � Keep connected with your chat all the time.

Custom Messaging � Each campaign can have its own specific messaging, branding, and more.

1 Click Access - Customers can access the chat from any mobile browser or app



**More Benefits** Convert More Mobile Visitors (Desktop too!) 

Easy to Learn & Setup. (We will setup your first campaign, Just ask!) 

How to Videos to Help You Get Setup.

Professional Sales Chat for your Mobile Website 

You're Trial Starts when you Chat with your First Customer.



Ready to use MobiChat for Free? Go to <a href="https://www.mbct.me/manager/signup3" target="_blank">http://www.mobichat.com</a>

== Changelog ==

0.1.0

* Feature: Add the MobiChat live chat widget to your site!
* Feature: Customize look and feel of the widget on your mobile website. 

== Screenshots ==

Desktop Agent Interface 

Linked MobiChat Account

Chat On Your Mobile Site

Chat on Desktop Site 



== Frequently Asked Questions ==

=Are there any limitations on the free trial?=

No your free trial gives you access to all the features paid accounts have for 30 days. 

=Do you provide support to help me get setup?=

Yes! From the time you sign up you get access to our entire support team. We can even create your first campaign, lead captures, and more. 

=Do I need to have a windows PC to login as agent?=

=I need help with EVERYTHING? Can you help! = 

Yes We Can! We are here to help it's top priority. We can help setup your first campaign, lead capture, and more. Our success is your success. Reach out to support via live chat or email support@mobichat.com and let's get you started! This goes for free trials too! 

How much does MobiChat cost?

We have a special pricing plan in place for Wordpress users. You can use Mobichat for just $19 a month per agent. Before making that decision you can take part in a full feature free trial for 5 agents with no credit card required. 

== Usage ==

This is the first version of the MobiChat Live Chat plugin for Wordpress. 

== Installation ==

*Server Requirements:* PHP4 or PHP5.

*Wordpress versions:* Wordpress 2.7 and up.

Step-by-step Guide:

Please visit <a href="http://blog.mobichat.com/wordpress" target="_blank">http://blog.mobichat.com/wordpress</a> for instructions on how to setup this plugin. 

We want to make it easy for you to get MobiChat live on your site. From inside the plugin you can access instructions and even chat with our support team. We added our chat inside of the plugin admin!

You can also email us support@mobichat.com if you need assistance. We can help you through every step and even set up your first campaign.




